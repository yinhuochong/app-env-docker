<?php if(!defined('ROOT')) die('Access denied.');

$_CFG = array();

$_CFG['siteBaseUrl'] = "http://localhost/hong/";
$_CFG['siteDefaultLang'] = "Auto";
$_CFG['siteDefaultTemplate'] = "Default";
$_CFG['siteActived'] = "1";
$_CFG['siteRewrite'] = "0";
$_CFG['siteTemplateCheck'] = "1";
$_CFG['siteTimezone'] = "+8";
$_CFG['siteDateFormat'] = "Y-m-d";
$_CFG['siteActived'] = "1";
$_CFG['siteOffTitle'] = "网站正在进行数据维护，请稍后光临，谢谢！";
$_CFG['siteOffTitleEn'] = "Website maintaining, please visit later, thanks!";
$_CFG['siteTitle'] = "HongCMS中英文企业网站系统";
$_CFG['siteTitleEn'] = "HongCMS Company Website System";
$_CFG['siteCopyright'] = "HongCMS中英文企业网站系统";
$_CFG['siteCopyrightEn'] = "HongCMS Company Website System";
$_CFG['siteKeywords'] = "HongCMS,中英文,企业网站系统";
$_CFG['siteKeywordsEn'] = "HongCMS,company website,system";
$_CFG['siteBeian'] = "京ICP备888888号";
$_CFG['siteSmall'] = "80";
$_CFG['siteMiddle'] = "400";
$_CFG['siteLarge'] = "900";
$_CFG['siteAppVersion'] = "3.0.0";
$_CFG['siteAppName'] = "HongCMS";
$_CFG['siteEmail'] = "go@gogo.com";
$_CFG['siteUseSmtp'] = "0";
$_CFG['siteSmtpHost'] = "smtp.yoursite.com";
$_CFG['siteSmtpEmail'] = "yourname@yoursite.com";
$_CFG['siteSmtpPort'] = "25";
$_CFG['siteSmtpUser'] = "yourname";
$_CFG['siteSmtpPassword'] = "efefef";

?>