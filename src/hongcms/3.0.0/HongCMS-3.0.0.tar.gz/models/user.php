<?php if(!defined('ROOT')) die('Access denied.');

class user{ 
    function gogo(){
       echo "<br>Hello, world go 6666!";
    } 
} 
?>