<?php
	$HongCMSversion = '3.0.0';
?>