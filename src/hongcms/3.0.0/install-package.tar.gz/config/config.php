<?php if(!defined('ROOT')) die('Access denied.');

$servername  = 'localhost';
$dbname      = 'hongcms';
$dbusername  = 'root';
$dbpassword  = '';

define('TABLE_PREFIX', 'hong_');
define('COOKIE_KEY', 'KpqyZPO0Wwrj');
define('WEBSITE_KEY', 't3fBKheVw4nO');
define('SYSDIR', '/');

?>